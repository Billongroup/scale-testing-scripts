from fpdf import FPDF
import uuid
from lorem_text import lorem
import os


def generate_with_dir(directory):
    if not os.path.exists("Documents/"+directory):
        os.makedirs("Documents/"+directory)
        # Generate a unique identifier using uuid
        unique_id = str(uuid.uuid4())

        # save FPDF() class into a
        # variable pdf
        pdf = FPDF()

        # Add a page
        pdf.add_page()

        # set style and size of font
        # that you want in the pdf
        pdf.set_font("Arial", size=12)

        # create a cell
        bodyTxt = ""

        # ADDING RANDOM TEXT
        documentSize = 1
        amountOfLoremIpsum = 1
        for a in range(amountOfLoremIpsum):
            paragraph_length = 1
            bodyTxt += lorem.paragraphs(paragraph_length)

        # add another cell
        pdf.multi_cell(0, 3, txt=bodyTxt, align='L')

        # save the pdf with name .pdf
        nameofDoc = f"Documents/{directory}/document_" + unique_id + ".pdf"
        pdf.output(nameofDoc)
        return nameofDoc


def generate_given(name):
    if os.path.exists(name):
        return name
    # save FPDF() class into a
    # variable pdf
    pdf = FPDF()

    unique_id = str(uuid.uuid4())

    # Add a page
    pdf.add_page()

    # set style and size of font
    # that you want in the pdf
    pdf.set_font("Arial", size=12)

    # create a cell
    bodyTxt = ""

    # ADDING RANDOM TEXT
    documentSize = 1
    amountOfLoremIpsum = 1
    for a in range(amountOfLoremIpsum):
        paragraph_length = 1
        bodyTxt += lorem.paragraphs(paragraph_length)

    # Add the variable 'name' to the content
    bodyTxt = f"{unique_id}: {name}\n\n{bodyTxt}"

    # add another cell
    pdf.multi_cell(0, 3, txt=bodyTxt, align='L')

    pdf.output(name)
    return name


def generate():
    # Generate a unique identifier using uuid
    unique_id = str(uuid.uuid4())

    # save FPDF() class into a
    # variable pdf
    pdf = FPDF()

    # Add a page
    pdf.add_page()

    # set style and size of font
    # that you want in the pdf
    pdf.set_font("Arial", size=12)

    # create a cell
    bodyTxt = ""

    # ADDING RANDOM TEXT
    documentSize = 1
    amountOfLoremIpsum = 1
    for a in range(amountOfLoremIpsum):
        paragraph_length = 1
        bodyTxt += lorem.paragraphs(paragraph_length)

    # add another cell
    pdf.multi_cell(0, 3, txt=bodyTxt, align='L')

    # save the pdf with name .pdf
    nameofDoc = "Documents/document_" + unique_id + ".pdf"
    pdf.output(nameofDoc)
    return nameofDoc


def generate_empty():
    # Generate a unique identifier using uuid
    unique_id = str(uuid.uuid4())
    # save the pdf with name .pdf
    nameofDoc = "Documents/document_" + unique_id + ".pdf"
    return nameofDoc

