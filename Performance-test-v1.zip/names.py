# PUBLIC
chemistry = "Chemistry"
battery_cells = "Battery Cells"
battery_packs = "Battery Packs"
batteries_tech_review = ["Batteries tech review 1", "Batteries tech review 2"]
battery_packs_repair = "Battery Packs Repair"
battery_repurpose_remanuf = "Battery Repurpose, remanuf"
battery_packs_recycling = "Battery Packs recycling"
battery_waste = "Battery Waste"
car_dealers_sales_confirm = "Car dealers- sales confirmation"

# PRIVATE
battery_cells_shipping_conf = "Battery Cells - shipping conf"
chemistry_test_results_private = "Chemistry Test results -private"
battery_cells_test_private = "Battery Cells test -private"
battery_cells_recieving_confir = "Battery Cells -recieving confir"
battery_packs_test_private = "Battery Packs -test -private"
car_dealers_shipping_confirm = "Car dealers- shiping confim"
#car_dealers_sales_confirmation = "Car dealers- sales confirmation"

data_sets_names = ["Chemistry",
                   "Battery Cells",
                   "Battery Packs",
                   "Batteries tech review 1",
                   "Batteries tech review 2",
                   "Battery Packs Repair",
                   "Battery Repurpose, remanuf",
                   "Battery Packs recycling",
                   "Battery Waste",
                   "Car dealers- sales confirmation"
                   ]

private_data_sets_names = ["Chemistry Test results -private",
                           "Battery Cells test -private",
                           "Battery Cells - shipping conf",
                           "Battery Cells -recieving confir",
                           "Battery Packs -test -private",
                           "Car dealers- shiping confim",
                           ]

categories = {
    "Chemistry": "chemistry",
    "Battery Cells": "batteryCells",
    "Battery Packs": "batteryPacks",
    "Batteries tech review 1": "batteriesTechReview",
    "Batteries tech review 2": "batteriesTechReview",
    "Battery Packs Repair": "batteryPacksRepair",
    "Battery Repurpose, remanuf": "batteryRepurpose",
    "Battery Packs recycling": "batteryPacksRecycling",
    "Battery Waste": "batteryWaste",

    "Chemistry Test results -private": "chemistryTestResults",
    "Battery Cells test -private": "batteryCellsTest",
    "Battery Cells - shipping conf": "batteryCellsShippingCofirmation",
    "Battery Cells -recieving confir": "batteryCellsReceivingConfirmation",
    "Battery Packs -test -private": "batteryPackTest",
    "Car dealers- shiping confim": "carDealersShippingConfirmation",
    "Car dealers- sales confirmation": "carSalersShippingConfirmation"
}
