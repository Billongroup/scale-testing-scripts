import pandas as pd
import json
import os
import names
import simple_tools
import yaml


def camel_case(input_string):
    words = input_string.split(' ')
    result = ""
    for i, word in enumerate(words):
        if not word:
            continue
        if i > 0:
            word = word.capitalize()
        result += word
    return result[0].lower() + result[1:]


def get_receiver_url(product_desc, sheet_name):
    if sheet_name in names.private_data_sets_names:
        try:
            return product_desc['receiver_url']
        except:
            return "receiver_url"


def get_cif(product_desc, sheet_name):
    if sheet_name in names.private_data_sets_names:
        try:
            return product_desc['blockchain_id']
        except:
            return "blockchain_id"


def get_default_url_from_config():
    try:
        with open('config.yaml', 'r') as config_file:
            config_data = yaml.load(config_file, Loader=yaml.FullLoader)
            default_url = config_data.get('default_publisher')
            return default_url
    except FileNotFoundError:
        print("File 'config.yaml' not found.")
    except Exception as e:
        print(f"Error reading config.yaml: {e}")
    return "173.249.48.101:17530"


def excel_to_json(input_file, sheet_name, start=1, end=None, _all=False, header=0):
    if header == 0 and sheet_name in names.data_sets_names:
        header = 1
    elif header == 0 and sheet_name in names.private_data_sets_names:
        header = 1
    df = pd.read_excel(input_file, sheet_name=sheet_name, header=header)

    if _all:
        start = 1
        end = len(df)
    else:
        if end is None:
            end = len(df)

    columns = df.columns
    json_list = []

    for index in range(start - 1, end):
        row_data = df.iloc[index]
        row_json = {column: str(row_data[column]).replace('\n', ' ').replace('\u00a0', ' ') for column in columns}
        json_list.append(row_json)

    return json_list


def get_company_url(company_name):
    if company_name is not None:
        for root, _, files in os.walk("Companies"):
            for file in files:
                if file.endswith(".json"):
                    file_path = os.path.join(root, file)
                    with open(file_path, "r") as json_file:
                        try:
                            data = json.load(json_file)
                            for item in data:
                                if company_name in json.dumps(item):
                                    return item.get("url")
                        except json.JSONDecodeError as e:
                            pass  # Continue searching other files
    return None


def get_url_from_sheet(product_desc):
    keys_to_search = ["Server & Port", "Server IP port", "Server:IP"]
    for key in keys_to_search:
        if key in product_desc:
            return product_desc[key]
    return None


def create_title(product_desc, sheet_name):
    if sheet_name in names.private_data_sets_names:
        if sheet_name == names.chemistry_test_results_private:
            return ["Chemistry Test Result"]
        elif sheet_name == names.battery_cells_test_private:
            return ["Battery Cells Test Result"]
        elif sheet_name == names.battery_cells_shipping_conf:
            return ["Battery Cells Shipping Confirmation"]
        elif sheet_name == names.battery_cells_recieving_confir:
            return ["Battery Cells Receiving Confirmation"]
        elif sheet_name == names.battery_packs_test_private:
            return ["Battery Packs Test"]
    if sheet_name == names.battery_packs:
        return ["User Manual", "Car Manual", "Description of Recycling"]
    if sheet_name == names.battery_cells:
        return ["Tech Specifications", "Certificates of Conformity 1", "Certificates of Conformity 2"]
    if sheet_name in names.batteries_tech_review:
        return ["Batteries tech review"]
    elif sheet_name == names.battery_packs_repair:
        return ["Battery Packs Repair"]
    elif sheet_name == names.battery_repurpose_remanuf:
        return ["Battery Repurpose"]
    elif sheet_name == names.battery_packs_recycling:
        return ["Battery Packs Recycling"]
    elif sheet_name == names.battery_waste:
        return ["Battery Waste"]
    elif sheet_name == names.car_dealers_sales_confirm:
        return ["Car Dealers Sales Confirmation"]
    elif sheet_name == names.car_dealers_shipping_confirm:
        return ["Car Dealers Shipping Confirmation"]
    return [product_desc[list(product_desc.keys())[4]]]


def create_additional_details(product_desc, sheet_name):
    a_d = {}
    product_list = list(product_desc.keys())
    product_desc = simple_tools.replace_nan_with_null(product_desc)
    if sheet_name == names.chemistry:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[1]]
        a_d["chemistryMarketName"] = product_desc[product_list[2]]
        a_d["productId"] = product_desc[product_list[3]]
        a_d["chemicalNameorMaterial"] = product_desc[product_list[5]]
        a_d["molecularFormula"] = product_desc[product_list[6]]
        a_d["sourced"] = product_desc[product_list[7]]
        a_d["productionDate"] = product_desc["Production Date"]
        a_d["chemicalComposition"] = []
        for i in range(8, 21):
            a_d["chemicalComposition"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
        a_d["particleSizeDistribution"] = []
        for i in range(21, 24):
            a_d["particleSizeDistribution"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["electrochemicalPerformance"] = product_desc["Electrochemical Performance - Specification"]
        a_d["physicalProperties"] = []
        for i in range(25, 28):
            a_d["physicalProperties"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
        a_d["lithiumProducer"] = []
        for i in range(29, 36):
            a_d["lithiumProducer"].append(
                {"label": camel_case(product_list[i]).replace('.1',''), "value": product_desc[product_list[i]]})
        a_d["cobaltProducer"] = []
        for i in range(36, 43):
            a_d["cobaltProducer"].append({"label": camel_case(product_list[i]).replace('.1',''), "value": product_desc[product_list[i]]})

    elif sheet_name == names.battery_cells:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[2]]
        a_d["productId"] = product_desc[product_list[3]]
        a_d["producer"] = []
        for i in range(19, 23):
            a_d["producer"].append({camel_case(product_list[i]): product_desc[product_list[i]]})
        a_d["producer"].append({"coordinates": product_desc[product_list[23]]})
        a_d["producer"].append({"childLaborScoring(6Max,1Min)": product_desc[product_list[28]]})
        a_d["producer"].append({"humanRightsScoring(6max,1Min)": product_desc[product_list[29]]})
        a_d["producer"].append({"esgScoring(6max,1Min)": product_desc[product_list[30]]})
        a_d["details"] = []
        a_d["details"].append({camel_case(product_list[1]): product_desc[product_list[1]]})
        for i in range(4, 14):
            a_d["details"].append({camel_case(product_list[i]): product_desc[product_list[i]]})
        for i in range(16, 19):
            a_d["details"].append({camel_case(product_list[i]): product_desc[product_list[i]]})
        for i in range(24, 28):
            a_d["details"].append({camel_case(product_list[i]): product_desc[product_list[i]]})
        for i in range(31, 33):
            a_d["details"].append({camel_case(product_list[i]): product_desc[product_list[i]]})
        a_d["details"].append({camel_case(product_list[34]): product_desc[product_list[34]]})
        a_d["details"].append({camel_case(product_list[38]): product_desc[product_list[38]]})
        a_d["details"].append({camel_case(product_list[39]): product_desc[product_list[39]]})

    elif sheet_name == names.battery_packs:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["productId"] = product_desc[product_list[3]]
        a_d["producer"] = []
        for i in range(13, 17):
            a_d["producer"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["producer"].append({"label": "childLaborScoring(6Max,1Min)", "value": product_desc[product_list[23]]})
        a_d["producer"].append({"label": "humanRightsScoring(6max,1Min)", "value": product_desc[product_list[24]]})
        a_d["producer"].append({"label": "esgScoring(6max,1Min)", "value": product_desc[product_list[25]]})
        a_d["details"] = []
        for i in range(1, 11):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(12, 13):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(17, 23):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(26, 30):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["sizeCalculation"] = []
        for i in range(33, 36):
            a_d["sizeCalculation"].append({"label": camel_case(product_list[i]).replace('.1',''), "value": product_desc[product_list[i]]})
        a_d["sizeCalculation"].append({"label": camel_case(product_list[38]), "value": product_desc[product_list[38]]})

    elif sheet_name in names.batteries_tech_review:
        if sheet_name == names.batteries_tech_review[0]:
            a_d["productId"] = product_desc[product_list[4]] + product_desc[product_list[0]]
        else:
            a_d["productId"] = product_desc[product_list[4]] + product_desc[product_list[0]]
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[1]]
        a_d["details"] = []
        for i in range(2, 18):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        try:
            a_d["details"].append({"label": camel_case(product_list[18]), "value": product_desc[product_list[18]]})
        except:
            return a_d

    elif sheet_name == names.battery_packs_repair:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[1]]
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(2, 14):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(16, 22):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["producer"] = []
        a_d["producer"].append({"label": "company", "value": product_desc[product_list[14]]})
        a_d["producer"].append({"label": "factoryLocation", "value": product_desc[product_list[15]]})

    elif sheet_name == names.battery_repurpose_remanuf:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[1]]
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(2, 12):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(15, 18):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["producer"] = []
        a_d["producer"].append({"label": "company", "value": product_desc[product_list[12]]})
        a_d["producer"].append({"label": "factoryLocation", "value": product_desc[product_list[13]]})
        a_d["producer"].append({"label": "coordinates", "value": product_desc[product_list[14]]})

    elif sheet_name == names.battery_packs_recycling:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[1]]
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(2, 9):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(12, 16):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(17, 18):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["details"].append({"label": camel_case(product_list[16]), "value": str(int(float(product_desc[product_list[16]]) * 100))})

        a_d["producer"] = []
        a_d["producer"].append({"label": "company", "value": product_desc[product_list[9]]})
        a_d["producer"].append({"label": "companyHeadquarters", "value": product_desc[product_list[10]]})
        a_d["producer"].append({"label": "factoryLocation", "value": product_desc[product_list[11]]})

    elif sheet_name == names.battery_waste:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["controlNumber"] = product_desc[product_list[1]]
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(2, 4):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["details"].append({"label": "batteryPackSerialNumberShort", "value": product_desc[product_list[4]]})
        for i in range(5, 10):
            a_d["details"].append({"label": camel_case(product_list[i]).replace('.1',''), "value": product_desc[product_list[i]]})
        for i in range(13, 17):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        for i in range(18, 19):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
        a_d["details"].append({"label": camel_case(product_list[17]), "value": str(int(float(product_desc[product_list[17]]) * 100))})

        a_d["producer"] = []
        a_d["producer"].append({"label": "company", "value": product_desc[product_list[10]]})
        a_d["producer"].append({"label": "factoryLocation", "value": product_desc[product_list[11]]})
        a_d["producer"].append({"label": "coordinates", "value": product_desc[product_list[12]]})
    elif sheet_name == names.car_dealers_sales_confirm:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["productId"] = product_desc[product_list[3]]+product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(1, 22):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})

    # PRIVATE
    elif sheet_name == names.chemistry_test_results_private:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(1, 38):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})

    elif sheet_name == names.battery_cells_test_private:
        a_d["assemblyNumber"] = product_desc[product_list[1]]
        a_d["details"] = []
        a_d["details"].append({"label": camel_case(product_list[0]), "value": product_desc[product_list[0]]})
        for i in range(2, 8):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})

    elif sheet_name == names.battery_cells_shipping_conf:
        a_d["productId"] = product_desc[product_list[2]]
        a_d["details"] = []
        for i in range(0, 3):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_cells_recieving_confir:
        a_d["assemblyNumber"] = product_desc[product_list[1]]
        a_d["details"] = []
        a_d["details"].append({"label": camel_case(product_list[0]), "value": product_desc[product_list[0]]})
        for i in range(2, 4):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})

    elif sheet_name == names.battery_packs_test_private:
        a_d["assemblyNumber"] = product_desc[product_list[0]]
        a_d["details"] = []
        for i in range(1, 18):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})

    elif sheet_name == names.car_dealers_shipping_confirm:
        a_d["details"] = []
        for i in range(1, 22):
            a_d["details"].append({"label": camel_case(product_list[i]), "value": product_desc[product_list[i]]})
    return a_d


def get_document_path(product_desc, sheet_name):
    product_list = list(product_desc.keys())
    if sheet_name == names.battery_cells:
        publication_src = product_desc["Tech Specifications"].replace('\\', '/').replace('PDF', 'pdf')
        try:
            update_1 = product_desc["Certificates of Conformity 1"].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_1 = product_desc["Certificates of Conformity 1"]
        try:
            update_2 = product_desc["Certificate of Conformity 2"].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_2 = product_desc["Certificate of Conformity 2"]
        paths = [publication_src, update_1, update_2]
        result = []
        for path in paths:
            if path is not None:
                if path.startswith('/'):
                    path = path[1:]
                result.append(path)
        return result
    elif sheet_name == names.battery_packs:
        publication_src = product_desc["User Manual"].replace('\\', '/').replace('PDF', 'pdf')
        try:
            update_1 = product_desc[product_list[38]].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_1 = product_desc[product_list[38]]
            print("src_2 is None")
        try:
            update_2 = product_desc[product_list[32]].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_2 = product_desc[product_list[32]]
            print("src_3 is None")
        paths = [publication_src, update_1, update_2]
        result = []
        for path in paths:
            if path is not None:
                if path.startswith('/'):
                    path = path[1:]
                result.append(path)
        return result
    return []


def get_company_for_product(product_desc):
    keys_to_search = ["Company", "Company Full name", "Recyclmen Company Full Name", "Recycler", "Company Full Name"]

    for key in keys_to_search:
        if key in product_desc:
            return product_desc[key]

    return None
