import sender
import sys
from data_modifier import *
import names


def main():
    excel_file = 'Battery Dataset -finalizedv5.xlsm'
    start_row = 4
    end_row = 7

    if len(sys.argv) >= 4:
        is_company = sys.argv[1] == "true"
        if is_company == "true":
            is_company = True
        else:
            is_company = False
        if len(sys.argv) == 7:
            sheet = sys.argv[2]+" "+sys.argv[3]+" "+sys.argv[4]+" "+sys.argv[5]
            publish = sys.argv[6]
        elif len(sys.argv) == 6:
            sheet = sys.argv[2]+" "+sys.argv[3]+" "+sys.argv[4]
            publish = sys.argv[5]
        elif len(sys.argv) == 5:
            sheet = sys.argv[2]+" "+sys.argv[3]
            publish = sys.argv[4]
        elif len(sys.argv) == 4:
            sheet = sys.argv[2]
            publish = sys.argv[3]
        else:
            print("WRONG ARGUMENTS")
            exit()
        if publish == "true":
            publish = True
        else:
            publish = False
    else:
        print('WRONG ARGUMENTS GIVEN')
        return  # Exit if no arguments given
    print("Loading Data From: "+sheet)
    result_json = excel_to_json(excel_file, sheet, start_row, end_row)
    output_json_file = sheet + ".json"

    with open(output_json_file, 'w') as f:
        json.dump(result_json, f, indent=4)

    if is_company:
        return  # Exit if the "is_company" argument is true

    for result in result_json:
        title = create_title(result, sheet).rstrip().strip()
        try:
            company = get_company_for_product(result).rstrip().strip()
        except:
            print("Failed to get company for product")
            company = None
        url = get_company_url(company)
        additional_details = create_additional_details(result, sheet)
        additional_details = json.dumps(additional_details, ensure_ascii=False)
        additional_details = str(additional_details).replace("None", "null")
        document_path = get_document_path(result, sheet)
        print(f"LOADED DATA: \ntitle: {title}\nadditional details: {additional_details}\nurl: {url}\ndocuments paths: {document_path}")
        if publish:
            sender.prepare_as_public(sheet, url, names.categories[sheet], title, additional_details, document_path)
    print(f"Dane zostały przekonwertowane i zapisane do {output_json_file}")


if __name__ == "__main__":
    main()
