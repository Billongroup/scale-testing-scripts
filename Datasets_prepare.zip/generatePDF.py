from fpdf import FPDF
import datetime
import time
from lorem_text import lorem
# assigned regular string date

def generate():
    date_time = datetime.datetime.now()
    unixTime = time.mktime(date_time.timetuple())
    unixTimeStr = str(unixTime)


    # save FPDF() class into a
    # variable pdf
    pdf = FPDF()

    # Add a page
    pdf.add_page()

    # set style and size of font
    # that you want in the pdf
    pdf.set_font("Arial", size=1)

    # create a cell

    bodyTxt = ""


    # ADDING RANDOM TEXT
    documentSize = 3
    amountOfLoremIpsum = int(700*(documentSize/1000))
    for a in range(amountOfLoremIpsum):
        paragraph_length = 10
        bodyTxt += lorem.paragraphs(paragraph_length)

    # add another cell
    pdf.cell(200, 10, txt=bodyTxt,ln=2, align='C')

    # save the pdf with name .pdf
    nameofDoc = "document" + unixTimeStr
    pdf.output(nameofDoc+".pdf")
    return nameofDoc

