import requests
import jxmlease
import base64
import generatePDF
import re
import time
import names
from pathlib import Path
from PyPDF2 import PdfReader, PdfWriter
from DurableMediaTest import PublicationSlot, LoopStats, SinglePublisherState, GlobalState
from DurableMediaTestConfig import Config


def save_blockchain(blockchain_address):
    try:
        with open("blockchains.txt", 'a') as file:
            file.write(blockchain_address + '\n')
        print("Saved to txt")
    except Exception as e:
        print("Error saving blockchain to txt", str(e))


def add_unixtime_metadata(pdf_path):
    reader = PdfReader(pdf_path)
    writer = PdfWriter()
    unix_time = str(int(time.time()))
    writer.append_pages_from_reader(reader)
    metadata = reader.metadata
    writer.add_metadata(metadata)

    # Write your custom metadata here:
    writer.add_metadata({"unixTime": unix_time})

    with open(pdf_path, "wb") as fp:
        writer.write(fp)


# TODO reader powinien byc rony od readera
def prepare_as_public(sheet_name, url, category, title, additional_details, document_path=None, blockchain=None):
    conf = Config()
    single_publisher = SinglePublisherState(conf, url, 1, global_state=GlobalState(), private=False, reportCatalog=Path('reportName').stem, readUrl= url)
    single_publisher.initSharedState()
    if document_path is None:
        name_of_doc = generatePDF.generate()
        with open(name_of_doc + ".pdf", "rb") as f:
            encodedZip = base64.b64encode(f.read())
        sourceDoc_b64 = encodedZip.decode()
    else:
        file_path = document_path['src_1']
        add_unixtime_metadata(pdf_path=file_path)
        with open(file_path, "rb") as pdf_file:
            pdf_data = pdf_file.read()
            base64_data = base64.b64encode(pdf_data).decode("utf-8")
            sourceDoc_b64 = base64_data
    pub = PublicationSlot(publisher=url, status='READY_TO_PUBLISH', blockchainAddress=blockchain)
    loop_stats = LoopStats()
    if not single_publisher.processPublication(pub, loop_stats, threadNo=1, content=sourceDoc_b64,
                                               additional_details=additional_details, documentMainCategory=category,
                                               title=title):
        return

    blockchain = pub.blockchainAddress
    save_blockchain(blockchain)
    pub2 = PublicationSlot(publisher=url, status='READY_TO_PUBLISH', blockchainAddress=pub.blockchainAddress)
    if sheet_name == names.battery_cells:
        for path in document_path:
            if document_path[path] == "" or document_path[path] == 'nan':
                continue
            if path == 'src_2':
                single_publisher.processPublication(pub2, loop_stats, threadNo=1, content=sourceDoc_b64,
                                                    additional_details=additional_details,
                                                    documentMainCategory=category, title="Certificates of Conformity 1")

            elif path == 'src_3':
                single_publisher.processPublication(pub2, loop_stats, threadNo=1, content=sourceDoc_b64,
                                                    additional_details=additional_details,
                                                    documentMainCategory=category, title="Certificates of Conformity 2")
            elif sheet_name == names.battery_packs:
                for path in document_path:
                    if document_path[path] == "" or document_path[path] == 'nan':
                        continue
                    if path == 'src_2':
                        single_publisher.processPublication(pub2, loop_stats, threadNo=1, content=sourceDoc_b64,
                                                            additional_details=additional_details,
                                                            documentMainCategory=category, title="Car Manual")
                    elif path == 'src_3':
                        single_publisher.processPublication(pub2, loop_stats, threadNo=1, content=sourceDoc_b64,
                                                            additional_details=additional_details,
                                                            documentMainCategory=category,
                                                            title="Description of Recycling")
