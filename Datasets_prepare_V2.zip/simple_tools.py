

def replace_nan_with_null(input_dict):
    if isinstance(input_dict, dict):
        for key, value in input_dict.items():
            if isinstance(value, dict):
                input_dict[key] = replace_nan_with_null(value)
            elif isinstance(value, list):
                input_dict[key] = [replace_nan_with_null(item) for item in value]
            elif value == "nan":
                input_dict[key] = None
    return input_dict
