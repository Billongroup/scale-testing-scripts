chemistry = "Chemistry"
battery_cells = "Battery Cells"
battery_packs = "Battery Packs"
batteries_tech_review = ["Batteries tech review 1", "Batteries tech review 2"]
battery_packs_repair = "Battery Packs Repair"
battery_repurpose_remanuf = "Battery Repurpose, remanuf"
battery_packs_recycling = "Battery Packs recycling"
battery_waste = "Battery Waste"
# PRIVATE
battery_cells_shipping_conf = "Battery Cells - shipping conf"
data_sets_names = ["Chemistry",
                   "Battery Cells",
                   "Battery Packs",
                   "Batteries tech review 1",
                   "Batteries tech review 2",
                   "Battery Packs Repair",
                   "Battery Repurpose, remanuf",
                   "Battery Packs recycling",
                   "Battery Waste"]

private_data_sets_names = []

categories = {
    "Chemistry": "chemistry",
    "Battery Cells": "batteryCells",
    "Battery Packs": "batteryPacks",
    "Batteries tech review 1": "batteriesTechReview",
    "Batteries tech review 2": "batteriesTechReview",
    "Battery Packs Repair": "batteryPacksRepair",
    "Battery Repurpose, remanuf": "batteryRepurpose",
    "Battery Packs recycling": "batteryPacksRecycling",
    "Battery Waste": "batteryWaste",
    "Battery Cells - shipping conf": "batteryCellsShippingCofirmation"
}
