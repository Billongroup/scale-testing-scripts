import pandas as pd
import json
import os
import names
import simple_tools
import yaml


def get_receiver_url(product_desc, sheet_name):
    if sheet_name == names.battery_cells_shipping_conf:
        try:
            return product_desc['receiver_url']
        except:
            return "receiver_url"


def get_cif(product_desc, sheet_name):
    if sheet_name == names.battery_cells_shipping_conf:
        try:
            return product_desc['blockchain_id']
        except:
            return "blockchain_id"


def get_default_url_from_config():
    try:
        with open('config.yaml', 'r') as config_file:
            config_data = yaml.load(config_file, Loader=yaml.FullLoader)
            default_url = config_data.get('default_publisher')
            return default_url
    except FileNotFoundError:
        print("File 'config.yaml' not found.")
    except Exception as e:
        print(f"Error reading config.yaml: {e}")
    return "173.249.48.101:17529"


def excel_to_json(input_file, sheet_name, start=1, end=None, _all=False, header=0):
    if header == 0 and sheet_name in names.data_sets_names:
        header = 1
    df = pd.read_excel(input_file, sheet_name=sheet_name, header=header)

    if _all:
        start = 1
        end = len(df)
    else:
        if end is None:
            end = len(df)

    columns = df.columns
    json_list = []

    for index in range(start - 1, end):
        row_data = df.iloc[index]
        row_json = {column: str(row_data[column]).replace('\n', ' ').replace('\u00a0', ' ') for column in columns}
        json_list.append(row_json)

    return json_list


def get_company_url(company_name):
    if company_name is not None:
        for root, _, files in os.walk("Companies"):
            for file in files:
                if file.endswith(".json"):
                    file_path = os.path.join(root, file)
                    with open(file_path, "r") as json_file:
                        try:
                            data = json.load(json_file)
                            for item in data:
                                if company_name in json.dumps(item):
                                    return item.get("url")
                        except json.JSONDecodeError as e:
                            pass  # Continue searching other files
    return None


def create_title(product_desc, sheet_name):
    if sheet_name in names.batteries_tech_review:
        return "Batteries tech review"
    elif sheet_name == names.battery_packs_repair or sheet_name == names.battery_repurpose_remanuf:
        return "Battery Packs Repair"
    elif sheet_name == names.battery_packs_recycling:
        return "Battery Packs Recycling"
    elif sheet_name == names.battery_waste:
        return "Battery Waste"
    elif sheet_name == names.battery_cells_shipping_conf:
        return "Battery Cells Shipping Confirmation"

    return product_desc[list(product_desc.keys())[4]]


def create_additional_details(product_desc, sheet_name):
    a_d = {}
    product_list = list(product_desc.keys())
    product_desc = simple_tools.replace_nan_with_null(product_desc)
    if sheet_name == names.chemistry:
        a_d["no"] = product_desc[product_list[0]]
        a_d["noNew"] = product_desc[product_list[1]]
        a_d["chemistryMarketName"] = product_desc[product_list[2]]
        a_d["productId"] = product_desc[product_list[3]]
        a_d["chemicalNameorMaterial"] = product_desc[product_list[5]]
        a_d["molecularFormula"] = product_desc[product_list[6]]
        a_d["sourced"] = product_desc[product_list[7]]
        a_d["productionDate"] = product_desc["Production Date"]
        a_d["chemicalComposition"] = [{"label": "Li (wt%)", "value": product_desc["Li (wt%)"]},
                                      {"label": "Na (wt%)", "value": product_desc["Na (wt%)"]},
                                      {"label": "Fe (wt%)", "value": product_desc["Fe (wt%)"]},
                                      {"label": "Cu (wt%)", "value": product_desc["Cu (wt%)"]},
                                      {"label": "H2O (wt%)", "value": product_desc["H2O (wt%)"]},
                                      {"label": "Li2C03 (wt%)", "value": product_desc["Li2C03 (wt%)"]},
                                      {"label": "Ni (mol%)", "value": product_desc["Ni (mol%)"]},
                                      {"label": "Mn (mol%)", "value": product_desc["Mn (mol%)"]},
                                      {"label": "Co (mol%)", "value": product_desc["Co (mol%)"]},
                                      {"label": "Ca (wt%)", "value": product_desc["Ca (wt%)"]},
                                      {"label": "P  (wt%)", "value": product_desc["P  (wt%)"]},
                                      {"label": "Pb  (wt%)", "value": product_desc["Pb  (wt%)"]},
                                      {"label": "C ( wt%)", "value": product_desc["C ( wt%)"]}]
        a_d["particleSizeDistribution"] = [{"label": "D10", "value": product_desc["D10"]},
                                           {"label": "D50", "value": product_desc["D50"]},
                                           {"label": "D90", "value": product_desc["D90"]}]
        a_d["electrochemicalPerformance"] = product_desc["Electrochemical Performance - Specification"]
        a_d["physicalProperties"] = [{"label": "BET (m2/g)", "value": product_desc["BET (m2/g)"]},
                                     {"label": "Tap Density (g/cm3)", "value": product_desc["Tap Density (g/cm3)"]},
                                     {"label": "pH", "value": product_desc["pH"]}]
        a_d["lithiumProducer"] = [{"label": "No", "value": product_desc["No.1"]},
                                  {"label": "Company", "value": product_desc["Company"]},
                                  {"label": "Company Headquaters", "value": product_desc["Company Headquaters"]},
                                  {"label": "Mine", "value": product_desc["Mine"]},
                                  {"label": "Coordinates", "value": product_desc["Coordinates"]},
                                  {"label": "Child Labor scoring (6 max, 1 min)", "value": product_desc["Child Labor scoring (6 max, 1 min)"]},
                                  {"label": "Human Rights Scoring (6max, 1 Min)", "value": product_desc["Human Rights Scoring (6max, 1 Min)"]}]
        a_d["cobaltProducer"] = [{"label": "No", "value": product_desc["No.2"]},
                                 {"label": "Company", "value": product_desc["Company.1"]},
                                 {"label": "Company Headquaters", "value": product_desc["Company Headquaters.1"]},
                                 {"label": "Mine", "value": product_desc["Mine.1"]},
                                 {"label": "Coordinates", "value": product_desc["Coordinates.1"]},
                                 {"label": "Child Labor scoring (6 max, 1 min)", "value": product_desc["Child Labor scoring (6 max, 1 min).1"]},
                                 {"label": "Human Rights Scoring (6max, 1 Min)", "value": product_desc["Human Rights Scoring (6max, 1 Min).1"]}]
    elif sheet_name == names.battery_cells:
        a_d["no"] = product_desc[product_list[0]]
        a_d["noNew"] = product_desc[product_list[2]]
        a_d["productId"] = product_desc[product_list[3]]
        a_d["producer"] = []
        a_d["producer"].append({"label": product_list[1], "value": product_desc[product_list[1]]})
        for i in range(18, 22):
            a_d["producer"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
        a_d["details_1"] = []
        for i in range(4, 19):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
        a_d["details_2"] = []
        for i in range(25, 34):
            a_d["details_2"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_packs:
        a_d["no"] = product_desc[product_list[0]]
        a_d["productId"] = product_desc[product_list[3]]
        a_d["producer"] = []
        for i in range(13, 16):
            a_d["producer"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
        for i in range(23, 25):
            a_d["producer"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
        a_d["details_1"] = []
        for i in range(4, 12):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name in names.batteries_tech_review:
        if sheet_name == names.batteries_tech_review[0]:
            a_d["productId"] = product_desc[product_list[4]]+"A" + product_desc[product_list[0]]
        else:
            a_d["productId"] = product_desc[product_list[4]] + "B" + product_desc[product_list[0]]
        a_d["no"] = product_desc[product_list[0]]
        a_d["noNew"] = product_desc[product_list[1]]
        a_d["details_1"] = []
        a_d["details_1"].append({"label": product_list[2], "value": product_desc[product_list[2]]})
        for i in range(2, 18):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_packs_repair:
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details_1"] = []
        for i in range(4, 20):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_repurpose_remanuf:
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details_1"] = []
        for i in range(4, 16):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_packs_recycling:
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details_1"] = []
        for i in range(4, 16):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_waste:
        a_d["productId"] = product_desc[product_list[4]]+product_desc[product_list[0]]
        a_d["details_1"] = []
        for i in range(4, 18):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    elif sheet_name == names.battery_cells_shipping_conf:
        a_d["productId"] = product_desc[product_list[2]]
        a_d["details_1"] = []
        for i in range(0, 3):
            a_d["details_1"].append({"label": product_list[i], "value": product_desc[product_list[i]]})
    return a_d


def get_document_path(product_desc, sheet_name):
    product_list = list(product_desc.keys())
    if sheet_name == names.battery_cells:
        publication_src = product_desc["Tech Specifications"].replace('\\', '/').replace('PDF', 'pdf')
        try:
            update_1 = product_desc["Certificates of Conformity 1"].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_1 = product_desc["Certificates of Conformity 1"]
        try:
            update_2 = product_desc["Certificate of Conformity 2"].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_2 = product_desc["Certificate of Conformity 2"]
        paths = [publication_src, update_1, update_2]
        result = []
        for path in paths:
            if path is not None:
                if path.startswith('/'):
                    path = path[1:]
                    result.append(path)
        return result
    elif sheet_name == names.battery_packs:
        publication_src = product_desc["User Manual"].replace('\\', '/').replace('PDF', 'pdf')
        try:
            update_1 = product_desc[product_list[38]].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_1 = product_desc[product_list[38]]
            print("src_2 is None")
        try:
            update_2 = product_desc[product_list[31]].replace('\\', '/').replace('PDF', 'pdf')
        except:
            update_2 = product_desc[product_list[31]]
            print("src_3 is None")
        paths = [publication_src, update_1, update_2]
        result = []
        for path in paths:
            if path is not None:
                if path.startswith('/'):
                    path = path[1:]
                    result.append(path)
        return result
    return None


def get_company_for_product(product_desc):
    keys_to_search = ["Company", "Company Full name", "Recyclmen Company Full Name", "Recycler", "Company Full Name"]

    for key in keys_to_search:
        if key in product_desc:
            return product_desc[key]

    return None
