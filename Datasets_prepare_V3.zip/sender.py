import os
import generatePDF
import yaml
import time
from PyPDF2 import PdfReader as PdfR, PdfWriter as PdfW
from pdfrw import PdfReader, PdfWriter
from io import BytesIO

import simple_tools


def save_blockchain(blockchain_address, _id=""):
    try:
        with open("blockchains.txt", 'a') as file:
            file.write(_id+" "+blockchain_address + '\n')
        print("Saved to txt")
    except Exception as e:
        print("Error saving blockchain to txt", str(e))


def create_prepared(url, title, additional_details, category, source_documents, name, product_id, cif=None, receiver_url=None):
    prepared_folder = 'Prepared'
    if not os.path.exists(prepared_folder):
        os.makedirs(prepared_folder)

    prepared_file_path = os.path.join(prepared_folder, f'{name}')

    try:
        with open(prepared_file_path, 'r') as prepared_file:
            existing_data = yaml.load(prepared_file, Loader=yaml.FullLoader)
            if existing_data is None or (isinstance(existing_data, list) and not existing_data):
                existing_data = []
    except FileNotFoundError:
        existing_data = []
    if cif is None:
        new_data = {
            'url': url,
            'title': title,
            'external_id': product_id,
            'additional_details': additional_details,
            'category': category,
            'source_documents': source_documents,
            'is_private': False
        }
    else:
        new_data = {
            'url': url,
            'blockchain_id': cif,
            'title': title,
            'external_id': product_id,
            'additional_details': additional_details,
            'category': category,
            'source_documents': source_documents,
            'receiver_url': receiver_url,
            'is_private': True
        }

    existing_data.append(new_data)

    with open(prepared_file_path, 'w') as prepared_file:
        yaml.dump(existing_data, prepared_file)
    print(f'Data saved to file {prepared_file_path}')


def add_unixtime_metadata(pdf_path, product_id):
    time.sleep(1)
    reader = PdfR(pdf_path)
    writer = PdfW()
    unix_time = int(time.time())
    writer.append_pages_from_reader(reader)
    metadata = reader.metadata
    writer.add_metadata(metadata)

    # Write your custom metadata here:
    writer.add_metadata({"/TimeUnix": f'(D:{str(unix_time)})', "/ProductId": f'{str(product_id)}'})
    pdf_path = str(pdf_path).replace('.pdf',f'{unix_time}.pdf')
    with open(pdf_path, "wb") as fp:
        writer.write(fp)
    return pdf_path


# TODO reader powinien byc rony od readera
def prepare_as_public(url, category, title, additional_details, name_of_prepared, product_id, document_path=None, blockchain=None):
    url = "http://" + url
    if document_path is None:
        name_of_doc = generatePDF.generate()
        trailer = PdfReader(name_of_doc)
        myio = BytesIO()
        PdfWriter(trailer=trailer).write(myio)
        myio.seek(0)
        document_path = [name_of_doc]
    else:
        # file_path = document_path[0]
        new_document_path = []
        for file_path in document_path:
            file_path = add_unixtime_metadata(pdf_path=file_path, product_id=product_id)
            trailer = PdfReader(file_path)
            myio = BytesIO()
            PdfWriter(trailer=trailer).write(myio)
            myio.seek(0)
            new_document_path.append(file_path)

        document_path = new_document_path

    create_prepared(url=url, title=title, additional_details=additional_details, category=category, source_documents=document_path, name=name_of_prepared, product_id=product_id)

    return


def prepare_as_private(sheet_name, url, category, title, additional_details, name_of_prepared, product_id, document_path=None, cif=None, receiver_url=None, blockchain=None):
    url = "http://"+url
    if document_path is None:
        name_of_doc = generatePDF.generate()
        trailer = PdfReader(name_of_doc)
        myio = BytesIO()
        PdfWriter(trailer=trailer).write(myio)
        myio.seek(0)
        document_path = {'src_1': name_of_doc}
    else:
        file_path = document_path[0]
        add_unixtime_metadata(pdf_path=file_path, product_id=product_id)
        trailer = PdfReader(file_path)
        myio = BytesIO()
        PdfWriter(trailer=trailer).write(myio)
        myio.seek(0)
    create_prepared(url, title, additional_details, category, document_path, name_of_prepared, product_id=product_id, cif=cif, receiver_url=receiver_url)
    return
