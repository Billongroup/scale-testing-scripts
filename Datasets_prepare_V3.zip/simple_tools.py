import os
import re


def replace_nan_with_null(input_dict):
    if isinstance(input_dict, dict):
        for key, value in input_dict.items():
            if isinstance(value, dict):
                input_dict[key] = replace_nan_with_null(value)
            elif isinstance(value, list):
                input_dict[key] = [replace_nan_with_null(item) for item in value]
            elif value == "nan":
                input_dict[key] = None
    return input_dict


def clear_space():
    for filename in os.listdir("Documents"):
        if filename.endswith(".pdf"):
            file_path = os.path.join("Documents", filename)
            os.remove(file_path)

    for filename in os.listdir("manuals"):
        if re.search(r'\d{10}\.pdf$', filename):
            file_path = os.path.join("manuals", filename)
            os.remove(file_path)
            print(f"Usunięto plik: {file_path}")
    for filename in os.listdir("orders"):
        if re.search(r'\d{10}\.pdf$', filename):
            file_path = os.path.join("orders", filename)
            os.remove(file_path)
    for filename in os.listdir("Recycling instructions"):
        if re.search(r'\d{10}\.pdf$', filename):
            file_path = os.path.join("Recycling instructions", filename)
            os.remove(file_path)

    for filename in os.listdir("tech spec"):
        if re.search(r'\d{10}\.pdf$', filename):
            file_path = os.path.join("tech spec", filename)
            os.remove(file_path)

    for filename in os.listdir("Tech specs"):
        if re.search(r'\d{10}\.pdf$', filename):
            file_path = os.path.join("Tech specs", filename)
            os.remove(file_path)
