import os
import re


for filename in os.listdir("Documents"):
    if filename.endswith(".pdf"):
        file_path = os.path.join("Documents", filename)
        os.remove(file_path)

# Iteruj przez pliki w folderze "manuals" i usuń pliki z unix time w nazwie
for filename in os.listdir("manuals"):
    if re.search(r'\d{10}\.pdf$', filename):
        file_path = os.path.join("manuals", filename)
        os.remove(file_path)
for filename in os.listdir("orders"):
    if re.search(r'\d{10}\.pdf$', filename):
        file_path = os.path.join("orders", filename)
        os.remove(file_path)
for filename in os.listdir("Recycling instructions"):
    if re.search(r'\d{10}\.pdf$', filename):
        file_path = os.path.join("Recycling instructions", filename)
        os.remove(file_path)

for filename in os.listdir("tech spec"):
    if re.search(r'\d{10}\.pdf$', filename):
        file_path = os.path.join("tech spec", filename)
        os.remove(file_path)

for filename in os.listdir("Tech specs"):
    if re.search(r'\d{10}\.pdf$', filename):
        file_path = os.path.join("Tech specs", filename)
        os.remove(file_path)
for filename in os.listdir("compliance documentation"):
    if re.search(r'\d{10}\.pdf$', filename):
        file_path = os.path.join("compliance documentation", filename)
        os.remove(file_path)
