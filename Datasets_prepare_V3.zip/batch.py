import sys
import yaml
import sender
import datetime
import time

dir_filename = sys.argv[1]
index_slash = dir_filename.find("/")
if index_slash != -1:
    filename = dir_filename[index_slash + 1:]
else:
    print("WRONG FILE NAME, USE Prepared FOLDER")
    exit()
outputname = 'BATCH_'+filename

with open(dir_filename, 'r', encoding='utf-8') as stream:
    data_loaded = yaml.safe_load(stream)

print(data_loaded)
additional_details = []
date_time = datetime.datetime.now()
unixTime = time.mktime(date_time.timetuple())
unixTimeStr = str(unixTime)
title = "Batch_"+unixTimeStr
category = data_loaded[0]['category']
url = data_loaded[0]['url']
product_id = [data_loaded[0]['external_id']]
for data in data_loaded:
    additional_details.append(data)

sender.prepare_as_public(url, category, title, additional_details, outputname, product_id)
